% Example script to perform EM inference 
% 
% The script generates some data from a simple Rescorla-Wagner model, and then
% fits the data. 
% 
% Copyright Quentin Huys, 2015 
% qhuys@cantab.net
% 
%==============================================================

clear all; 

Nsj = 20; 	% number of subjects
T = 100; 	% number of choices per subject 
Np = 2; 		% number ofa parmeters 

try 
	matlabpool open 4 ; 						% try opening matlabpool to speed things up 
end


%--------------------------------------------------------------
% generate some surrogate data 
%--------------------------------------------------------------

Etrue = randn(Np,Nsj);						% random parameters
reg = randn(1,Nsj); 							% random psychometric regressor 
Etrue(2,:) = Etrue(2,:) + reg;			% make parameter 2 correlated with regressor

% generate actual data 
for sk=1:Nsj;
	[a,r] = genrw(Etrue(:,sk),T);
	D(sk).A = a; 
	D(sk).R = r;
	D(sk).Nch = T; 

	AA(sk,:) = a; 
end


%--------------------------------------------------------------
% inference 
%--------------------------------------------------------------

regressors = cell(Np,1); 					% set up regressor cell structure 
regressors{2} = reg;							% put our psychometric regressor into cell structure

% now run the actual inference 
[E,V,alpha,stats,bf,fitparams] = emfit('llrw2',D,Np,regressors); 


%--------------------------------------------------------------
% some plots 
%--------------------------------------------------------------

subplot(231);
imagesc(AA);
colormap(gray*.3+.7)
hold on
plot(mean(AA==1)*20,'k','linewidth',2);
hold off
yy = linspace(0,Nsj,6); 
set(gca,'ytick',yy,'yticklabel',1-round(yy/Nsj*10)/10)
ylabel('Average choice probability')
xlabel('Time')
title('Choice data');

subplot(232);
errorbar(Etrue(1,:),E(1,:),sqrt(V(1,:)),'o');
xlabel('True log \beta');
ylabel('Inferred log \beta');

subplot(233);
errorbar(Etrue(2,:),E(2,:),sqrt(V(2,:)),'o');
xlabel('True \sigma^{-1}(\alpha)');
ylabel('Inferred \sigma^{-1}(\alpha)');

subplot(223);
bar([alpha(1:2) ]);
hold on;
errorbar(1:2,alpha(1:2),sqrt(stats.groupmeanerr(1:2)),'.'); 
plot([.5 1.5],[0 0],'r--');
hold off;
h=text(.6, 0.1,'True');
set(h,'color','r');
ylabel('Estimated prior group means');

subplot(224);
bar([alpha(3) ]);
hold on;
errorbar(1,alpha(3),sqrt(stats.groupmeanerr(3))); 
plot([.5 1.5],[1 1],'r--');
hold off;
h=text(.6, 1.1,'True');
set(h,'color','r');
ylabel('Estimated regression coefficient');

